# import mysql.connector as c
#
# con = c.connect(host="localhost", user="root", passwd="Pg.vijay@7248", database="arsenal")
# cursor = con.cursor()
# query = "select *from arsn_data"
# # query = input("Enter your query: ")
# # count = int(input("Enter your count: "))
# # query_time = input("Enter query_time as 2002-09-05 05:05:05  : ")
# # try:
# #
# #     query_data = "insert into arsn_data(query,count,query_time) values('{}',{},'{}')".format(query, count, query_time)
# #     cursor.execute(query_data)
# # except Exception as e:
# #     # query='how are you prateek?'
# #     query_update = "update arsn_data set count = count + 1 where query = '{}'".format(query)
# #     query_update1 = "update arsn_data set query_time = '{}' where query = '{}'".format(query_time,query)
# #     cursor.execute(query_update)
# #     cursor.execute(query_update1)
# # format_query = "select * from ars_data order by id"
# # cursor.execute(format_query)
# cursor.execute(query)
# print("Id   Query       Count   Date & Time")
# for row in cursor:
#     print(row[0],"\t",row[1],"\t\t",row[2],"\t",row[3])
#     # print(row[3])
# con.commit()
#
# print("data updated into tables\n")
#
# # import smtplib
# #
# # content = 'hello world'
# # email = 'gkbr221698@gmail.com'
# # password = 'pg.vijay'
# # to = 'parteekgoyal.8057996696@gmail.com'
# #
# #
# # def sendEmail(to, content):
# #     server = smtplib.SMTP('smtp.gmail.com', 587)
# #     server.ehlo()
# #     server.starttls()
# #     server.login(email, password)
# #     server.sendmail(email, to, content)
# #
# #
# # sendEmail(to, content)
# # print('successfully transferred')

names = ["prateek", "prachi", "ujjawal", "prerna", "shubhankar", "yash", "deepanshi", "himanshu", "anirudh", "aaradhya",
         'aayush', 'neeraj', 'kailash']
numbers = [['+91 72488 44385', 'prateek.goel.cs.2019@mitmeerut.ac.in'],
           ['+91 76685 11296', 'prachi.cs.2019@mitmeerut.ac.in'],
           ['+91 86302 24424', 'ujjawal.jindal.cs.2019@mitmeerut.ac.in'],
           ['+91 76687 73430', 'prerna.choudhary.cs.2019@mitmeerut.ac.in'],
           ['+91 98971 53347', 'shubhankar.mittal.cs.2019@mitmeerut.ac.in'],
           ['+91 84399 45310', 'yash.bansal.cs.2019@mitmeerut.ac.in'],
           ['+91 84330 99203', 'deepanshi.pal.cs.2019@mitmeerut.ac.in'],
           ['+91 97603 82653', 'himanshu.cs.2019@mitmeerut.ac.in'],
           ['+91 6396 189 212', 'anirudh.verma.cs.2019@mitmeerut.ac.in'],
           ['+91 79064 27794', 'aaradhya.saini.cs.2019@mitmeerut.ac.in'],
           ['+91 99979 62331', 'ayush.singhal@mitmeerut.ac.in'], ['+91 98973 35329', 'neeraj.pratap@mitmeerut.ac.in'],
           ['+91 86304 30234', 'kailash.tripathi@mitmeerut.ac.in']]

# numbers = ["+91 72488 44385", "+91 76685 11296", "+91 86302 24424", "+91 76687 73430", "+91 98971 53347",
#            "+91 84399 45310", "+91 84330 99203", "+91 97603 82653", "+91 6396 189 212", "+91 79064 27794",
#            "+91 99979 62331", "+91 98973 35329", "+91 86304 30234"]
# numbers = [[ +91 72488 44385 , ] [ +91 76685 11296 , ] [ +91 86302 24424 , ] [ +91 76687 73430 , ] [ +91 98971 53347 , ] [ +91 84399 45310 , ] [ +91 84330 99203 , ] [ +91 97603 82653 , ] [ +91 6396 189 212 , ] [ +91 79064 27794 , ] [ +91 99979 62331 , ] [ +91 98973 35329 , ] [ +91 86304 30234 , ]]


# ph = {'prateek': '+91 72488 44385', 'prachi': '+91 76685 11296', 'ujjawal': '+91 86302 24424', 'prerna': '+91 76687 73430', 'shubhankar': '+91 98971 53347', 'yash': '+91 84399 45310', 'deepanshi': '+91 84330 99203', 'himanshu': '+91 97603 82653', 'anirudh': '+91 6396 189 212', 'aaradhya': '+91 79064 27794', 'aayushneeraj': '+91 99979 62331', 'kailash': '+91 98973 35329'}
# ph = {'prateek': ['+91 72488 44385','prateek.goel.cs.2019@mitmeerut.ac.in'], 'prachi': '+91 76685 11296', 'ujjawal': '+91 86302 24424', 'prerna': '+91 76687 73430', 'shubhankar': '+91 98971 53347', 'yash': '+91 84399 45310', 'deepanshi': '+91 84330 99203', 'himanshu': '+91 97603 82653', 'anirudh': '+91 6396 189 212', 'aaradhya': '+91 79064 27794', 'aayush': '+91 99979 62331', 'neeraj': '+91 98973 35329', 'kailash': '+91 86304 30234'}
# print(ph['prateek'][0])
phone_dict = dict(zip(names, numbers))
print(type(phone_dict['prateek'][1]))
print(len('34343'))
# # temp = 'Prateek' in phone_dict
# print('prateek' in phone_dict.keys())
# print(phone_dict['prateek'])
print(phone_dict)
# for i in numbers:
#     print(f"['{i}',]",end=" ")
