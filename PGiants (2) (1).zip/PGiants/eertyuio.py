# # # # python='pythonasdfghj'
# # # # hel=python[-2:-5]
# # # # print(hel)
# # #
# # # minidict={'name':'TutorialsPoint', 'name':'website'}
# # # print(minidict['name'])
# # a=4
# # b=3
# # if a != b:
# #     print('hello')
# # di={'a':2,'b':3,'a':5}
# # print(di)
# # class A:
# #     print("hello")
#
# # A()
# # A()
# # obj=A()
#
# # s='prateek goel'
# # print(s.title())
# z=lambda x,y:y+x
# x=2
# y=5
# print(z(x,y))

# print(3//2+4-7+2*2+8/4)
# 1+4-7+4+2.0
#
# class A(object):
#     val =1
# class B(A):
#     pass
# class C(A):
#     pass
# B.val=2
# print(A.val,B.val,C.val)

# def Fucntion():
#     'python lecture at mit meerut'
#     return 1
# print(Fucntion.__doc__[10:14])

# l=[(x,y) for x in range(10) for y in range(10) if (x%2==0 and x>5 and y%2==0 and y>5)]
# print(l)

# print(35//3+2**3//3)
#35//3+8//3
#11+2
#13
# t={1:20,2:30,3:40,6:60,8:80}
# print(t[3:5])
#
# s={'a','b','c','d'}
# d={'c','a'}
# print(d.issubset(s))

# Python3 program to find
# minimum number of swaps
# required to sort an array

# Function returns the minimum
# number of swaps required to
# sort the array
# def minSwaps(arr):
#     n = len(arr)
#
#     # Create two arrays and use
#     # as pairs where first array
#     # is element and second array
#     # is position of first element
#     arrpos = [*enumerate(arr)]
#
#     # Sort the array by array element
#     # values to get right position of
#     # every element as the elements
#     # of second array.
#     arrpos.sort(key=lambda it: it[1])
#
#     # To keep track of visited elements.
#     # Initialize all elements as not
#     # visited or false.
#     vis = {k: False for k in range(n)}
#
#     # Initialize result
#     ans = 0
#     for i in range(n):
#
#         # alreadt swapped or
#         # alreadt present at
#         # correct position
#         if vis[i] or arrpos[i][0] == i:
#             continue
#
#         # find number of nodes
#         # in this cycle and
#         # add it to ans
#         cycle_size = 0
#         j = i
#
#         while not vis[j]:
#             # mark node as visited
#             vis[j] = True
#
#             # move to next node
#             j = arrpos[j][0]
#             cycle_size += 1
#
#         # update answer by adding
#         # current cycle
#         if cycle_size > 0:
#             ans += (cycle_size - 1)
#
#     # return answer
#     return ans
#
#
# # Driver Code
# arr = [9,8,7,6,5,4,3,2,1]
# print(minSwaps(arr))

# This code is contributed
# by Dharan Aditya

import getpass
passw = getpass.getpass(prompt='passw : ',stream=None)
print(passw)