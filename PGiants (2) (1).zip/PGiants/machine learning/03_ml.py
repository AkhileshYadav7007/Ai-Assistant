from sklearn import datasets
from sklearn.neighbors import KNeighborsClassifier

iris = datasets.load_iris()
# print(iris.DESCR)
features = iris.data
lables = iris.target
print(features[0], lables[0])

# training the classifier
clf = KNeighborsClassifier()
clf.fit(features, lables)

preds = clf.predict([[31, 1, 1, 1]])
print(preds)
