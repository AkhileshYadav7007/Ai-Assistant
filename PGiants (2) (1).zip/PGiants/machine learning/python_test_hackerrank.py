# # import math
# # import os
# # import random
# # import re
# # import sys
# #
# #
# # class Car:
# #     def __init__(self, max_speed, units):
# #         self.max_speed = max_speed
# #         self.units = units
# #
# #     def __str__(self):
# #         if max_speed >= 120:
# #             return 'Car with the maximum speed of ' + str(self.max_speed) + ' ' + str(self.units)
# #         else:
# #             return 'Car with the maximum speed of ' + str(self.max_speed) + ' ' + str(self.units)
# #
# #
# # class Boat:
# #     def __init__(self, max_speed):
# #         self.max_speed = max_speed
# #
# #     def __str__(self):
# #         return 'Boat with the maximum speed of ' + str(max_speed) + " knots"
# #
# #
# # if __name__ == '__main__':
# #     # fptr = open(os.environ['OUTPUT_PATH'], 'w')
# #     q = int(input())
# #     queries = []
# #     for i in range(q):
# #         args1 = list(input().split())
# #         vehicle_type, params = args1[0], args1[1:]
# #         if vehicle_type == "car":
# #             max_speed, speed_unit = int(params[0]), params[1]
# #             vehicle = Car(max_speed, speed_unit)
# #             print(vehicle)
# #         elif vehicle_type == "boat":
# #             max_speed = int(params[0])
# #             vehicle = Boat(max_speed)
# #             print(vehicle)
# #         else:
# #             raise ValueError("invalid vehicle type")
# #     #     fptr.write("%s\n" % vehicle)
# #     # fptr.close()
#
# if __name__ == '__main__':
#     final=[]
#     for _ in range(int(raw_input())):
#         a=[]
#         name = raw_input()
#         score = float(raw_input())
#         a.append(name)
#         a.append(score)
#         final.append(a)
#     # print(final)
#     for i in range(len(final)):
#         min = final[0][1]
#         min_1 = final[0][1]
#         if final[i][1]<min:
#             min_1=min
#             min = final[i][1]
#         elif (min != final[i][1]) and (final[i][1]<min_1):
#             min_1 = final[i][1]
#     f=[]
#     for i in range(len(final)):
#         if min_1 == final[i][1]:
#             f.append(final[i][0])
#     f = sorted(f)
#     for i in f:
#         print(i)

# Enter your code here. Read input from STDIN. Print output to STDOUT
num = input().split()
n, m = int(num[0]), int(num[1])
f = []
happy = 0
f = input().split()
f = list(map(int, f))
# for i in range(n):
# f.append(int(input()))
a = []
a = input().split()
a = list(map(int, a))
b = []
b = input().split()
b = list(map(int, b))
for i in a:
    if i in f:
        happy = happy + 1
for i in b:
    if i in f:
        happy = happy - 1
print(happy)



