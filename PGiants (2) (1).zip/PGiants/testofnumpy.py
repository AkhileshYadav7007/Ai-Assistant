# # # # # # # import   numpy as np
# # # # # # # arr = np.array([1,2,3,4,5,1,2])
# # # # # # # # print(arr.size * arr.itemsize)
# # # # # # # # print(arr.min())
# # # # # # # print(arr.argsort())
# # # # # # # HELLO = ['hello my  '
# # # # # # #          'ashfhchsgdfjahsdjkfhkjasfjksdahfkjhsdkjfsdkfhsdjkfhjksdhlfjksdhfkjashjfkhsdjfhjskfhkjshfkjsahfjksdhfkjlshjfdkjsdkhafjksfhjhjfkahsjkfhsdkjfhaskjfhsdkjfhjakshfjksdahfkjashfkjahlkjhsjkahfjkahfjkseehfjkashfjklsdahjfhajklhfjlkdshfjanhksjdhfahsfsdlkkjdaslkjdkls;jakl;jdsj;dsjka;jskdljakl;kdjsrlpatetekkprateek goelpratekke go3elprateek goelprtgateek gpemeetut institue of technokigh meeeut inxtutute of technokivh zndmeerut instutute ofe technokixfsmemetettuemeetut isngtututfnsdkjzfhkjasdhfjkshdkjfhlasdkjhfjdhfjkashjfkhsjkfhsdakjfhsdkjlfhjkasdfhjkasdhfjksd',2,3,4]
# # # # # # # assert len(HELLO) == 1
# # # # # # # HELLO[0].print()
# # # # # # from pywikihow import search_wikihow
# # # # # # query = input()
# # # # # # max_results = 1
# # # # # # how_to = search_wikihow(query, max_results)
# # # # # # # print(how_to)
# # # # # # assert len(how_to) == 1
# # # # # # how_to[0].print()
# # # # # # # speak(how_to[0].summary)
# # # # # import datetime
# # # # # print(datetime.datetime.now())
# # # # # date = (datetime.datetime.now())
# # # # # hour = int(datetime.datetime.now().hour)
# # # # # min = (datetime.datetime.now().minute)
# # # # # sec = (datetime.datetime.now().second)
# # # # # ms = (datetime.datetime.now().microsecond)
# # # # # print(ms)
# # # # # print(sec)
# # # # # print(min)
# # # # # print(hour)
# # # # # print(type(hour))
# # # # # # print(datetime.timedelta(date , datetime))
# # # # # print(datetime.tzinfo)
# # # # # print(datetime.timezone)
# # # # # delta = datetime.timedelta(
# # # # #      days=50,
# # # # #      seconds=27,
# # # # #      microseconds=10,
# # # # #      milliseconds=29000,
# # # # #      minutes=5,
# # # # #      hours=8,
# # # # #      weeks=59
# # # # # )
# # # # # print(delta)
# # # # # print(delta.max)
# # # # # print(delta.resolution)
# # # # # print(delta.total_seconds())
# # # # # print(date)
# # # # # print(datetime.datetime.today())
# # # # # print(date.today())
# # # # # # print(datetime.timedelta(datetime.datetime.now(),delta))
# # # # # # datetime.tim
# # # # # print(date.fromisoformat('2019-12-04'))
# # # # # print(date.year,date.month,date.day)
# # # # # print(date.weekday())
# # # # from datetime import date
# # # # import datetime
# # # #
# # # # birth_date = date.fromisoformat('2002-10-25')
# # # # print(f"your birth date is {birth_date} sir")
# # # # # print(birth_date.month)
# # # # # print(date.today().ctime())
# # # # # print(date.today().month)'
# # # #
# # # # print(datetime.timezone.utc)
# # # # tzinfo = datetime.timezone.utc
# # # # print(tzinfo)
# # # # print(datetime.tzinfo)
# # # # # # print(date)
# # # # # if date.today().month == birth_date.month:
# # # # #     if date.today().day == birth_date.day:
# # # # #         print('Happy birthday sir! i hope you will achieve everything in your life')
# # # # #     elif birth_date.day > date.today().day:
# # # # #         print('your birthday is coming sir!')
# # # # #         print('sir if you want i can cancel all your meeting for your birthday sir')
# # # # # else:
# # # # #     if date.today().month > birth_date.month:
# # # # #         delta = (date.today() - (birth_date.replace(birth_date.year,date.today().year)))
# # # # #     else:
# # # # #         year1 = str(birth_date.year)
# # # # #         year2 = (date.today().year)
# # # # #         # print(type(year1),year2)
# # # # #         # print(birth_date.replace(year=year2))
# # # # #         # print(birth_date.replace(birth_date.year, date.today().year))
# # # # #         # print(birth_date.year)
# # # # #         # delta = ((birth_date.replace(birth_date.year, date.today().year)) - date.today())
# # # # #     # print(delta.days)
# # # #
# # # # import os
# # # #
# # # # music_dir = 'C:\\Users\\parte\\Music'
# # # # songs = os.listdir(music_dir)
# # # # print("hello")
# # # # print(os.path.getctime(music_dir))
# # # # print('world')
# # # # song = songs[5]
# # # # # print(os.path.join(music_dir,song))
# # # # print(os.path.getsize(os.path.join(music_dir,song)))
# # # # # print(os.ctermid()) #only for unix to find file name
# # # # # print(music_dir)
# # # # # print(song)
# # # import cv2
# # #
# # # cam = cv2.VideoCapture(0)
# # #
# # # fourcc = cv2.VideoWriter_fourcc(*'XVID')
# # # out = cv2.VideoWriter('output.avi',fourcc,20.0,(680,480))
# # #
# # # while cam.isOpened():
# # #     ret , frame = cam.read()
# # #     if ret == True:
# # #
# # #         gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
# # #         cv2.imshow('frame',frame)
# # #         out.write(frame)
# # #         if cv2.waitKey(1) & 0xFF == ord('q'):
# # #             break
# # #     else:
# # #         break
# # #
# # # cam.release()
# # # cv2.destroyAllWindows()
# #
# # import wikipedia
# # query = input('Enter : ')
# # print(wikipedia.search(query, results=10, suggestion=False))
# # print(wikipedia.summary(query, sentences=10, chars=0, auto_suggest=True, redirect=True))
# # print(wikipedia.page(title=query, pageid=query, auto_suggest=True, redirect=True, preload=True))
#
# # import requests
# # import os
# # r = requests.get('https://www.google.com/technicalguruji')
# # print(r)
# # # s = 'technicalguruji'
# # # pd = r + '/' + s
# # # print(pd)
# # print(r)
# # print(r.url)
# # print(r.json())
# # import time
# # ti = time.strftime("%I:%M %p %A")
# # print(ti)
# # print(time.localtime())
# # print('hello')
# # time.sleep(5)
# # print('world')
# # print()
# import getpass
# # print('Enter your password: ')
# passw = getpass.getpass('enter')
# print(passw)
# from pyqt5 impor
# from PyQt5.uic import LoadUiType


from PyQt5.QtWidgets import *
from matplotlib.backends.backend_qt5agg import FigureCanvas
from matplotlib.figure import Figure


class Histogram(QWidget):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        self.canvas = FigureCanvas(Figure())

        vertical_layout = QVBoxLayout()
        vertical_layout.addWidget(self.canvas)

        self.canvas.sumbu1 = self.canvas.figure.add_subplot(111)
        self.canvas.figure.set_facecolor("xkcd:wheat")
        self.setLayout(vertical_layout)


# main_histogram.py
import cv2
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from matplotlib.backends.backend_qt5agg import (NavigationToolbar2QT as NavigationToolbar)
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtGui import QPixmap
import numpy as np
fname = ""


class Display_Histogram(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        loadUi("histogram.ui", self)

        self.setWindowTitle("Image Histogram")
        self.pbImage.clicked.connect(self.display_histogram)
        self.addToolBar(NavigationToolbar(self.widgetDisplay.canvas, self))

    def display_histogram(self):
        global fname
        fname = QFileDialog.getOpenFileName(self, 'Open file',
                                            'd:\\', "Image Files (*.jpg *.gif *.bmp *.png *.tiff)")
        pixmap = QPixmap(fname[0])
        self.labelImage.setPixmap(pixmap)
        self.labelImage.setScaledContents(True);

        self.widgetDisplay.canvas.sumbu1.clear()
        read_img = cv2.imread(fname[0], cv2.IMREAD_COLOR)
        color = ('b', 'g', 'r')
        for i, col in enumerate(color):
            histr = cv2.calcHist([read_img], [i], None, [256], [0, 256])
            self.widgetDisplay.canvas.sumbu1.plot(histr, color=col, linewidth=3.0)
            self.widgetDisplay.canvas.sumbu1.set_ylabel('Y', color='blue')
            self.widgetDisplay.canvas.sumbu1.set_xlabel('X', color='blue')
            self.widgetDisplay.canvas.sumbu1.set_title('Histogram')
            self.widgetDisplay.canvas.sumbu1.set_facecolor('xkcd:wheat')
            self.widgetDisplay.canvas.sumbu1.grid()
        self.widgetDisplay.canvas.draw()


if __name__ == '__main__':
    import sys

    app = QApplication(sys.argv)
    ex = Display_Histogram()
    ex.show()
    sys.exit(app.exec_())
